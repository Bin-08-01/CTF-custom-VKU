# Overload PWN

[Source code](./src/bof.c)

# Build

```bash
docker build -t bof-begin-pwn:lastest . 
docker run -p <port>:1337 <image id>
```